package ev2.examen;

public class Gafa_Graduada extends Gafa {
	
	public Gafa_Graduada(Montura montura, Lente lente_izq, Lente lente_der, double coste, double pvp) {
		super(montura, lente_izq, lente_der, coste, pvp);
		this.identificador++;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void aplicaDescuento() {
		int descuento = 10;
		double pvp_real = this.pvp - (descuento*this.pvp)/100;
		this.pvp = pvp_real;
	}
	
}
