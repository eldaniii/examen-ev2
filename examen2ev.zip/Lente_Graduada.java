package ev2.examen;

public class Lente_Graduada extends Lente {
	public enum problemas_visuales{ASTIGMATISMO, MIOPIA, HIPERMETROPIA};
	public double grado_correcion;
	private problemas_visuales probl_visual_lente;
	
	protected Lente_Graduada(posicion posicion_lente) {
		super(posicion_lente);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void dimeTipoLente() {
		System.out.println("GRADUADA: SI");
	}
}
