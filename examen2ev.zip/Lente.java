package ev2.examen;

public abstract class Lente {
	protected enum posicion{D, I};
	protected posicion posicion_lente;
	
	protected Lente(posicion posicion_lente) {
		super();
		this.posicion_lente = posicion_lente;
	}
	
	public abstract void dimeTipoLente();
}

