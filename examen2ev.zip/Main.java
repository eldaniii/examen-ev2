package ev2.examen;

public class Main {
	public static void main(String[] args) {
		Optica optica1 = new Optica(0);
		Gafa gafa1 = new Gafa_Graduada(null, null, null, 20, 0);
		Gafa gafa2 = new Gafa_Graduada(null, null, null, 20, 0);

		
		System.out.println(gafa1.coste);
		
		optica1.addGafa(Gafa.tipo_gafa.GRADUADA, gafa1);
		optica1.addGafa(Gafa.tipo_gafa.GRADUADA, gafa2);
		System.out.println(optica1.cuantasGafas());		
		//System.out.println(optica1.stock_gafas.);
		System.out.println(optica1.costeGafasByTipo(Gafa.tipo_gafa.GRADUADA));
		
		
	}
}
