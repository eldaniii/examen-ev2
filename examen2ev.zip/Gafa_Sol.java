package ev2.examen;

public class Gafa_Sol extends Gafa {
	public Proveedor proveedor_gafa;
	
	public Gafa_Sol(Montura montura, Lente lente_izq, Lente lente_der, double coste, double pvp, Proveedor proveedor_gafa) {
		super(montura, lente_izq, lente_der, coste, pvp);
		this.proveedor_gafa = proveedor_gafa;
		this.identificador++;
	}



	@Override
	public void aplicaDescuento() {
		double descuento = 5;
		double pvp_real = this.pvp - (descuento*this.pvp)/100;
		this.pvp = pvp_real;
	}
	
	
}
