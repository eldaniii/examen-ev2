package ev2.examen;

import java.io.Serializable;

public abstract class Gafa implements Promocion, Serializable {
	private static final long serialVersionUID = 1L;
	public enum tipo_gafa{GRADUADA, SOL};
	public static int identificador = 0;
	public Montura montura;
	public Lente lente_izq;
	public Lente lente_der;
	public double coste;
	public double pvp;
	public static int num_gafas_creadas = 0;
	
	public Gafa(Montura montura, Lente lente_izq, Lente lente_der, double coste, double pvp) {
		this.identificador++;
		this.montura = montura;
		this.lente_izq = lente_izq;
		this.lente_der = lente_der;
		this.coste = coste;
		this.pvp = pvp;
		this.num_gafas_creadas++;
	}
	
	
}
