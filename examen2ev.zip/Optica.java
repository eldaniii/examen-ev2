package ev2.examen;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import ev2.examen.Gafa.tipo_gafa;

public class Optica {
	public int num_gafas_stock;
	public HashMap<Gafa.tipo_gafa, Set<Gafa>> stock_gafas = new HashMap<Gafa.tipo_gafa, Set<Gafa>>();
	
	public Optica(int num_gafas_stock) {
		super();
		this.num_gafas_stock = num_gafas_stock;
	}

	public void addGafa(Gafa.tipo_gafa tipo, Gafa gafas) {
		
		stock_gafas.put(tipo, new HashSet<Gafa>());
		stock_gafas.get(tipo).add(gafas);
			
		/*set_tipo.addAll(stock_gafas.get(set_tipo));
		set_tipo.add(gafas);
		
		stock_gafas.put(tipo, set_tipo);*/
			
		num_gafas_stock++;
	}
	
	public int cuantasGafas() {
		return num_gafas_stock;
	}
	
	public boolean delGafa(Gafa gafas) {
		try {
			HashSet<Gafa> set_tipo = (HashSet) stock_gafas.values();
			set_tipo.remove(gafas);
			return true;
		} catch (Exception e) {
			System.out.println("No se han podido eliminar las gafas al stock.");
			return false;
		}
	}
	
	public void gafasByProveedor() {
		Set<Gafa> lista_gafas = stock_gafas.get(Gafa.tipo_gafa.SOL);
	}
	
	public double costeGafasByTipo(Gafa.tipo_gafa tipo) {
		double suma = 0;
		Set<Gafa> set_gafas = stock_gafas.get(tipo);
		for (Gafa gafa : set_gafas) {
			suma = suma + gafa.coste;
		}
		return suma;
	}
	
	public void generaFichero() {
		
	}
	
	public void cargaFichero() {
		
	}
}
