package ev2.examen;

public class Montura {
	public enum material{PASTA, METAL};
	public String marca;
	public material material_montura;
	public String color;
	public Montura(String marca, material material_montura, String color) {
		super();
		this.marca = marca;
		this.material_montura = material_montura;
		this.color = color;
	}
}
