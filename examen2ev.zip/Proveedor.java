package ev2.examen;

public class Proveedor {
	protected int CIF;
	protected String nombre;
	protected int tlf_contacto;
	
	public int compareTo(Proveedor o1, Proveedor o2) {
		// TODO Auto-generated method stub
		return o1.nombre.compareTo(o1.nombre);
	}
}
