package ev2.examen;

public class Lente_Sol extends Lente {
	public enum colores{VERDE, MARRON, GRIS};
	private colores color_lente;
	
	protected Lente_Sol(posicion posicion_lente) {
		super(posicion_lente);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void dimeTipoLente() {
		System.out.println("GRADUADA: NO");
	}
}
